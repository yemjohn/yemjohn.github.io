var add = nums => nums.reduce((a,b) => a+b,0);
console.log(add([5,6,7]));
var mult=nums => nums.reduce((a,b) => a*b,1);