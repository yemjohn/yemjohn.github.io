function max  (num1, num2, num3) {
    return (Math.max(num1, num2, num3));
}

var maxOfThree = max(24,34,4454);
console.log("The maximum number is" + maxOfThree);