function submit() {
    var show = document.getElementById("firstName");
    console.log (show);
}