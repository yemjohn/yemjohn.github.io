var f = function(num1, num2){
    return num1>num2 ? num1 : num2;
}

console.log(f(1,2));